package cmn;

public class DTO {
	
	
	
	

}
