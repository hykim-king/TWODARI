package com.pcwk.ehr.member;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.message.Message;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pcwk.ehr.cmn.Box;
import com.pcwk.ehr.cmn.PLog;
public class Main implements PLog{
	MemberDTO member01;
	MemberDTO member02;
	MemberDTO member03;
	
	Box<MemberDTO> box;
	
	MemberDao dao;
	
	public Main() {
		member01 = new MemberDTO("AAA01", "김", "a1234", "AAA01@gmail.com", "010-1111-1111", "2024-04-19", "admin");
		member02 = new MemberDTO("BBB02", "이", "b1234", "BBB02@gmail.com", "010-2222-2222", "2024-04-19", "admin");
		member03 = new MemberDTO("CCC03", "박", "c1234", "CCC03@gmail.com", "010-3333-3333", "2024-04-19", "admin");
		
		box = new Box<MemberDTO>();
		box.add(member01);
		box.add(member02);
		box.add(member03);
		dao = new MemberDao();
		dao.setListBox(box.getListBox());
		dao.doSaveFile();
	
	}
	public void doSave() {
		LOG.debug("doSave()");
		int flag = dao.doSave(new MemberDTO("ddd04", "최", "d1234", "ddd04@gmail.com", "010-4444-4444", "2024-04-19", "admin"));
		
		if(flag==1) {
			LOG.debug("-----------");
			LOG.debug("단건 등록 성공!");
			LOG.debug("-----------");
		}else {
			LOG.debug("단건 등록 실패! flag:"+flag);
		}
	}
	
	public void doDelete() {
		LOG.debug("doDelete()");
		int flag = dao.doDelete(member03);
		
		if(flag==1) {
			LOG.debug("-----------");
			LOG.debug("단건 삭제 성공!");
			LOG.debug("-----------");
		}else {
			LOG.debug("단건 삭제 실패!");
		}
		
		
		
	}
	
	public void doUpdate() {
		LOG.debug("doUpdate()");
		int flag = dao.doUpdate( new MemberDTO("AAA01", "김박수", "aa1234", "AAA01@gmail.com", "010-1111-1111", "2024-04-23", "admin"));
		if(2 == flag) {
			LOG.debug("-----------");
			LOG.debug("단건 수정 성공!");
			LOG.debug("-----------");
		}else {
			LOG.debug("단건 수정 실패!");
		}
		
		
	}
	
	public void doSelectOne() {
		//LOG.debug("doSelectOne()");
		MemberDTO dto = dao.doSelectOne(member01);
		
		if(null != dto) {
			LOG.debug("-----------");
			LOG.debug("단건 조회 성공!");
			LOG.debug(dto);
			LOG.debug("-----------");
		}else {
			LOG.debug("단건 조회 실패!");
		}
		
	 
		 
	}
	
	
		private void doRetrieve() {
			LOG.debug("doRetrieve()"); 
			List<MemberDTO> list = dao.doRetrieve(null);
			if(3 == list.size()) {
				LOG.debug("-----------");
				LOG.debug("목록 검색 성공!");
				LOG.debug("-----------");
			}else {
				LOG.debug("목록 검색 실패!");
			}
			for(MemberDTO dto :list) {
				LOG.debug(dto);
			} 
	}
		
		
		
		public void dispList(List<MemberDTO> list) {
			for(MemberDTO dto :list) {
				LOG.debug(dto);
			}
		}
		private void doRetrieveName() {
			LOG.debug("doRetrieveName()"); 
			
			SearchDTO search = new SearchDTO("10","김");
			List<MemberDTO> list = dao.doRetrieve(search);
			dispList(list);
	}
		
		private void doRetrieveEmail() {
			LOG.debug("doRetrieveEmail()"); 
			
			SearchDTO search = new SearchDTO("20","AAA01@gmail.com");
			List<MemberDTO> list = dao.doRetrieve(search);
			dispList(list);
	}
	
	public static void main(String[] args) {
		Main m = new Main();
 
		m.doRetrieveEmail();
		m.dao.doSaveFile(); 
		
	}

	/**
	 * 객체  to json
	 * @param fileName
	 * @return
	 */
	public int saveToJson(String fileName) {
		int count = 0;
		
		//PrerrtPrintng Json
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		
		try(FileWriter writer = new FileWriter(fileName)){
			
			gson.toJson(box, writer);
			count = box.getListBox().size();
			
			
		}catch(IOException e) {
			LOG.debug("IOException :"+e.getMessage());
			count = 0;
			
		}
		
		
		LOG.debug(fileName+"파일생성완료");
		return count;
		
	}
	
	public Box<MemberDTO> jsonToObject(String fileName){
		Box<MemberDTO> list = null;
		
		
		try(FileReader fr=new FileReader(fileName)){
			Gson gson = new Gson();
			
			list = gson.fromJson(fr, Box.class);
			
		}catch(IOException e) {
			LOG.debug("IOException :"+e.getMessage());
		}
		
		
		
		return list;
	}
	
	
	//객체 to json
}






 



