package com.pcwk.ehr.cmn;

public class DTO {
	
	
	
	

}
